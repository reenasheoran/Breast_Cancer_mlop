from setuptools import setup, find_packages

setup (
    name="source_files",
    version='0.0.1',
    description = "Breast cancer classification",
    author='reena',
    packages=find_packages(),
    licence='MIT'
)