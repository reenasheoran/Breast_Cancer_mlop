

def test_values():
    a=3
    b=3
    assert a==b